import base64, hashlib, json, os, shutil, subprocess, tarfile, threading
from pathlib import Path
from urllib.parse import unquote
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

root=Path(__file__).resolve().parent
project=root/'merchant-store'
assert not project.exists(), 'The clean installation must start in a new directory'
cache=root/'consumer-cache'
assert not cache.exists(), 'The consumer must start with a new npm cache'
archives = {}
manifests = {}
for archive in root.glob('stateset-embedded*.tgz'):
    with tarfile.open(archive) as tar:
        manifest = json.load(tar.extractfile('package/package.json'))
    with archive.open('rb') as stream:
        integrity = 'sha512-' + base64.b64encode(hashlib.sha512(stream.read()).digest()).decode()
    archives['/'+archive.name] = archive
    manifests['/'+manifest['name']] = manifest, archive, integrity
class Registry(BaseHTTPRequestHandler):
    def do_GET(self):
        key = unquote(self.path)
        if key in archives:
            archive = archives[key]
            self.send_response(200)
            self.send_header('Content-Type','application/octet-stream')
            self.send_header('Content-Length',str(archive.stat().st_size))
            self.end_headers()
            with archive.open('rb') as stream: shutil.copyfileobj(stream,self.wfile)
        elif key in manifests:
            manifest, archive, integrity = manifests[key]
            version = manifest['version']
            body = json.dumps({'name':manifest['name'], 'dist-tags':{'latest':version}, 'versions':{version:{**manifest, 'dist':{'integrity':integrity,'tarball':base+'/'+archive.name}}}}).encode()
            self.send_response(200)
            self.send_header('Content-Type','application/json')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else: self.send_error(404)
    def log_message(self, *args): pass

with ThreadingHTTPServer(('127.0.0.1',0),Registry) as server:
    base='http://127.0.0.1:'+str(server.server_port)
    server.daemon_threads=True
    threading.Thread(target=server.serve_forever,daemon=True).start()
    config=root/'consumer.npmrc'
    config.write_text('registry=https://registry.npmjs.org/\n@stateset:registry='+base+'/\n')
    env={**os.environ,'NPM_CONFIG_USERCONFIG':str(config),'npm_config_cache':str(cache),'npm_config_fund':'false','npm_config_update_notifier':'false'}
    with (root/'install.log').open('w') as log:
        subprocess.run(['npm','exec','--yes','--package='+str(root/'create-stateset-app-1.40.1.tgz'),'--','create-stateset-app',str(project),'--yes'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    server.shutdown()
lock=json.loads((project/'package-lock.json').read_text())
modules=project/'node_modules'
manifest=json.loads((project/'package.json').read_text())
assert manifest['dependencies']['@stateset/embedded']=='^1.40.1'
for name in ['@stateset/embedded','@stateset/embedded-linux-x64-gnu']:
    spec=lock['packages']['node_modules/'+name]
    package, archive, integrity=manifests['/'+name]
    assert spec['version']=='1.40.1' and spec['integrity']==integrity and spec['resolved']==base+'/'+archive.name
assert not list((modules/'@stateset/embedded').glob('*.node'))
assert (modules/'@stateset/embedded-linux-x64-gnu/stateset-embedded.linux-x64-gnu.node').is_file()
sources={entry['resolved'] for entry in lock['packages'].values() if entry.get('resolved')}
assert all(url.startswith(('https://registry.npmjs.org/',base+'/')) for url in sources)
print('Fresh npm install succeeded with '+str(len(sources)-2)+' third-party archives and two verified StateSet packages.')
